var searchData=
[
  ['named_5farg_0',['named_arg',['../args_8c.html#aab5cb37daa27a21e9a724fc3c7116b3c',1,'args.c']]],
  ['named_5farg_5fcount_1',['named_arg_count',['../structparsed__args.html#a900e8a1aef5d99920479254f50c5cb9c',1,'parsed_args']]],
  ['named_5farg_5fnames_2',['named_arg_names',['../structparsed__args.html#a0638499b83b47de252322ae65ffdacbf',1,'parsed_args']]],
  ['named_5farg_5fvalues_3',['named_arg_values',['../structparsed__args.html#aa5004f4b06b69cce5df93db223ea9a9d',1,'parsed_args']]],
  ['new_5fframe_4',['new_frame',['../paging_8h.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c'],['../paging_8c.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c']]],
  ['newest_5fswitch_5',['newest_switch',['../syntax__highlight_8c.html#a2e565f2eef0f1b48072d99211313e1d2',1,'syntax_highlight.c']]],
  ['next_5funnamed_5farg_6',['next_unnamed_arg',['../args_8c.html#ab20b340816a71f3368f6dd610678f8d8',1,'args.c']]],
  ['nframes_7',['nframes',['../paging_8c.html#abf36580d5618820f15388083c9313e60',1,'paging.c']]],
  ['nmi_8',['nmi',['../interrupts_8c.html#aa42d18df06cf68f8c05fded5344c4c7e',1,'interrupts.c']]],
  ['no_5ferror_9',['NO_ERROR',['../serial_8c.html#a258bb72419ef143530a2f8f55e7d57af',1,'serial.c']]],
  ['no_5fwarn_10',['no_warn',['../system_8h.html#ab3bb695e7817363c7bdb781f214e83a2',1,'system.h']]],
  ['nop_11',['nop',['../system_8h.html#a6c92c29fa8e83ab85e05543010e10d7c',1,'system.h']]],
  ['not_5fdeletable_12',['NOT_DELETABLE',['../pcb_8h.html#ab7bf7732db7ec98e16204b291146a924ab9f55b77742880dc1642e76b459672dd',1,'pcb.h']]],
  ['null_13',['NULL',['../system_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'system.h']]]
];
