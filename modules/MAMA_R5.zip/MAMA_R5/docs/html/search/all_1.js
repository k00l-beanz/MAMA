var searchData=
[
  ['access_0',['access',['../structgdt__entry__struct.html#a7457cb21f29e919a8ea62fc0110ac238',1,'gdt_entry_struct::access()'],['../tables_8h.html#a360a726ac0b61d9e4e1be3ad34f80244',1,'access():&#160;tables.h']]],
  ['accessed_1',['accessed',['../structpage__entry.html#a8b4097e0cee08d028182b11bd1f73f92',1,'page_entry']]],
  ['alarms_2',['alarms',['../dnt_8c.html#a2e9db90105225925ff7f66d38ea0128b',1,'dnt.c']]],
  ['alloc_3',['alloc',['../heap_8h.html#a2b1d5a9ba11695605f74fc10cd719af5',1,'alloc(u32int size, heap *hp, int align):&#160;heap.c'],['../heap_8c.html#a06dae34c7e7c73d518de00212a7c92da',1,'alloc(u32int size, heap *h, int align):&#160;heap.c']]],
  ['allocatepcb_4',['allocatePCB',['../pcb_2pcb_8c.html#a43b976f98a334dd955ebb9ec324a118d',1,'allocatePCB():&#160;pcb.c'],['../pcb_8h.html#a43b976f98a334dd955ebb9ec324a118d',1,'allocatePCB():&#160;pcb.c']]],
  ['args_2ec_5',['args.c',['../args_8c.html',1,'']]],
  ['args_2eh_6',['args.h',['../args_8h.html',1,'']]],
  ['argtest_2ec_7',['argtest.c',['../argtest_8c.html',1,'']]],
  ['asm_8',['asm',['../system_8h.html#a71921cebf4610b0dbb2b7a0daaf3fedf',1,'system.h']]],
  ['asm_2eh_9',['asm.h',['../asm_8h.html',1,'']]],
  ['atoi_10',['atoi',['../string_8h.html#a30670a60464f77af17dfb353353d6df8',1,'atoi(const char *s):&#160;string.c'],['../string_8c.html#a30670a60464f77af17dfb353353d6df8',1,'atoi(const char *s):&#160;string.c']]]
];
