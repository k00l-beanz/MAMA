var searchData=
[
  ['base_0',['base',['../structgdt__descriptor__struct.html#aa47407e7b435c214d0cdd22cb66f0e71',1,'gdt_descriptor_struct::base()'],['../structheap.html#a744634662f1ffdb4d85632e68c063e51',1,'heap::base()'],['../structidt__struct.html#a1a91fe2ab44ad8dfbad0f6d07ec789ea',1,'idt_struct::base()'],['../tables_8h.html#ab5763c2b18c825c8b8fba44b2e60ddc1',1,'base():&#160;tables.h']]],
  ['base_5fhigh_1',['base_high',['../structidt__entry__struct.html#a1c6a29cae5ea9a832cf4261aaa5b43d0',1,'idt_entry_struct::base_high()'],['../structgdt__entry__struct.html#aa03c14867c293012449a3b18a07f45f2',1,'gdt_entry_struct::base_high()'],['../tables_8h.html#a706c81b840522a69ab6e6e941630d5e4',1,'base_high():&#160;tables.h']]],
  ['base_5flow_2',['base_low',['../structidt__entry__struct.html#aefa75d6bfe07f1f544393b4dbccb3e76',1,'idt_entry_struct::base_low()'],['../structgdt__entry__struct.html#a90f05cd7f227a34e977a639843a23275',1,'gdt_entry_struct::base_low()'],['../tables_8h.html#a0a776dced2c26f16298425cde39f8364',1,'base_low():&#160;tables.h']]],
  ['base_5fmid_3',['base_mid',['../tables_8h.html#a35c709a004babd09046db9f667ba0646',1,'base_mid():&#160;tables.h'],['../structgdt__entry__struct.html#a0369f1e190c433425c5b0f40c2070715',1,'gdt_entry_struct::base_mid()']]],
  ['bcdtoi_4',['BCDtoI',['../dnt_8c.html#a25d183b9180e03fbd0a132749bfba7a3',1,'BCDtoI(unsigned char value):&#160;dnt.c'],['../dnt_8h.html#a25d183b9180e03fbd0a132749bfba7a3',1,'BCDtoI(unsigned char value):&#160;dnt.c']]],
  ['black_5',['BLACK',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3',1,'BLACK():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3',1,'BLACK():&#160;colorize.h']]],
  ['block_6',['block',['../structindex__entry.html#a0a8d4dc0595b5f2ef42e7080c5221c1f',1,'index_entry']]],
  ['blocked_7',['BLOCKED',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa376c1b6a3f75d283a2efacf737438d61',1,'pcb.h']]],
  ['blockhelp_8',['blockHelp',['../out_8h.html#ab4d4fa5b228678a329c2388e04a757f8',1,'blockHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#ab4d4fa5b228678a329c2388e04a757f8',1,'blockHelp():&#160;help.c']]],
  ['blockpcb_9',['blockPCB',['../pcb_2pcb_8c.html#ab54e65e3f05a13f84090f6ddebfc7f5a',1,'blockPCB(char *args):&#160;pcb.c'],['../pcb_8h.html#aac16cc6dc94063f48349fd852e3732ae',1,'blockPCB(char *name):&#160;pcb.c']]],
  ['blue_10',['BLUE',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1ca35d6719cb4d7577c031b3d79057a1b79',1,'BLUE():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1ca35d6719cb4d7577c031b3d79057a1b79',1,'BLUE():&#160;colorize.h']]],
  ['bounds_11',['bounds',['../interrupts_8c.html#a96724d36ad85f9a02231d8e6fe0434df',1,'interrupts.c']]],
  ['breakpoint_12',['breakpoint',['../interrupts_8c.html#a874043e2396dd8ce20ec7af3ea1e2a86',1,'interrupts.c']]],
  ['buffer_5fptr_13',['buffer_ptr',['../structparam.html#af15d63bace93014ec7425635c892ce99',1,'param']]]
];
