var searchData=
[
  ['last_5fstate_0',['last_state',['../args_8c.html#afbc486ac0bfaa0e3815cd0a79280490d',1,'args.c']]],
  ['left_5farrow_1',['LEFT_ARROW',['../serial_8c.html#ae78ccf44cb7970752cbfeb22e6a66d14',1,'serial.c']]],
  ['limit_2',['limit',['../structidt__struct.html#aa75e2805e21db1a33816af778263d712',1,'idt_struct::limit()'],['../structgdt__descriptor__struct.html#a3c8ae013805dd982b25f0d62e3cdee0e',1,'gdt_descriptor_struct::limit()'],['../tables_8h.html#a68fd3b4f6c14a331ca9b226cbf122e13',1,'limit():&#160;tables.h']]],
  ['limit_5flow_3',['limit_low',['../structgdt__entry__struct.html#ada721fbdc3e8d3feae3b07d4b82a37bd',1,'gdt_entry_struct::limit_low()'],['../tables_8h.html#af9013229edfb91d4820f66b8df890ce3',1,'limit_low():&#160;tables.h']]],
  ['load_5fpage_5fdir_4',['load_page_dir',['../paging_8h.html#a3affceba4cd194e1c516404c14abbe7c',1,'load_page_dir(page_dir *new_page_dir):&#160;paging.c'],['../paging_8c.html#a31e6c585cbda542534f1b0fc83e40689',1,'load_page_dir(page_dir *new_dir):&#160;paging.c']]],
  ['loadr3_5',['loadr3',['../context_8c.html#ace6cc1bdb64c3a0f48c1c31ad7757f9d',1,'loadr3(char *p):&#160;context.c'],['../context_8h.html#ace6cc1bdb64c3a0f48c1c31ad7757f9d',1,'loadr3(char *p):&#160;context.c']]],
  ['loadr3help_6',['loadr3Help',['../out_8h.html#a32a6a3edb1a000f0ab8bb969c37aa5ff',1,'loadr3Help():&#160;help.c'],['../term_2cmds_2help_8c.html#a32a6a3edb1a000f0ab8bb969c37aa5ff',1,'loadr3Help():&#160;help.c']]]
];
