var searchData=
[
  ['black_0',['BLACK',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3',1,'BLACK():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3',1,'BLACK():&#160;colorize.h']]],
  ['blocked_1',['BLOCKED',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa376c1b6a3f75d283a2efacf737438d61',1,'pcb.h']]],
  ['blue_2',['BLUE',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1ca35d6719cb4d7577c031b3d79057a1b79',1,'BLUE():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1ca35d6719cb4d7577c031b3d79057a1b79',1,'BLUE():&#160;colorize.h']]]
];
