var searchData=
[
  ['single_5fquote_5fstring_0',['SINGLE_QUOTE_STRING',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83ac1a06c479e02a744bff8252ce0b988e5',1,'syntax.h']]],
  ['single_5fquote_5fstring_5fend_5fquote_1',['SINGLE_QUOTE_STRING_END_QUOTE',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83ad584f45ce95cbda27206bc3a7a7e0c61',1,'syntax.h']]],
  ['suspended_5fblocked_2',['SUSPENDED_BLOCKED',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31faa4d91165aaa967e74157a23c02725bc7',1,'pcb.h']]],
  ['suspended_5fready_3',['SUSPENDED_READY',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa81cc2296827c731236176fea80701294',1,'pcb.h']]]
];
