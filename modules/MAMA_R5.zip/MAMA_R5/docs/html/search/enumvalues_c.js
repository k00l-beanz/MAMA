var searchData=
[
  ['yellow_0',['YELLOW',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1cae735a848bf82163a19236ead1c3ef2d2',1,'YELLOW():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1cae735a848bf82163a19236ead1c3ef2d2',1,'YELLOW():&#160;colorize.h']]]
];
