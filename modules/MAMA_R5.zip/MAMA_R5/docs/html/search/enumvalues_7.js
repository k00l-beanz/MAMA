var searchData=
[
  ['not_5fdeletable_0',['NOT_DELETABLE',['../pcb_8h.html#ab7bf7732db7ec98e16204b291146a924ab9f55b77742880dc1642e76b459672dd',1,'pcb.h']]]
];
