var searchData=
[
  ['f_5fqueue_0',['f_queue',['../pcb_2pcb_8c.html#a58df49d4ee18ae41d37f152507b1026f',1,'pcb.c']]],
  ['false_1',['FALSE',['../mpx__supt_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'mpx_supt.h']]],
  ['fetch_5fcmd_5fhandler_2',['fetch_cmd_handler',['../commhand_8c.html#a47c794d5c09edf314e8aa3280b425235',1,'commhand.c']]],
  ['fifo_3',['FIFO',['../pcb_8h.html#ab4997200d0dfc40cf82ea4983950ae64a7795ebef271efe70b28f37deb9a07a83',1,'pcb.h']]],
  ['fifo_5fqueue_4',['fifo_queue',['../pcb_2pcb_8c.html#a0bb729257e8ba26995a3ff7451f54134',1,'pcb.c']]],
  ['find_5ffree_5',['find_free',['../paging_8c.html#abe201f9294ab23125146fff36fe95187',1,'paging.c']]],
  ['findpcb_6',['findPCB',['../pcb_8h.html#a1fa60245485ed68db75b4626b44681ae',1,'findPCB(char *name):&#160;pcb.c'],['../pcb_2pcb_8c.html#a1fa60245485ed68db75b4626b44681ae',1,'findPCB(char *name):&#160;pcb.c']]],
  ['first_5ffree_7',['first_free',['../paging_8h.html#acb3c25257061521382c7ba900c1c1ab4',1,'paging.h']]],
  ['flag_8',['flag',['../args_8c.html#ab3e646d339c958582b4cea1c9ccbe20d',1,'args.c']]],
  ['flag_5fcount_9',['flag_count',['../structparsed__args.html#ade0889eea194c73f55eba0af1d874eca',1,'parsed_args']]],
  ['flags_10',['flags',['../structparsed__args.html#acddfaeda83e2d16d5b3b3f97b4afcc46',1,'parsed_args::flags()'],['../structgdt__entry__struct.html#afac75bdf53080168c8899c442862410a',1,'gdt_entry_struct::flags()'],['../structidt__entry__struct.html#a46c92bd8f07d5ff4e379a07b293c46af',1,'idt_entry_struct::flags()'],['../tables_8h.html#a138dda98fcd4738346af61bcca8cf4b4',1,'flags():&#160;tables.h']]],
  ['footer_11',['footer',['../structfooter.html',1,'']]],
  ['frameaddr_12',['frameaddr',['../structpage__entry.html#a68a6dc54a7ab6f7fb1a068476190bf67',1,'page_entry']]],
  ['frames_13',['frames',['../paging_8c.html#a76492529572a1a20a06076ac40d66b29',1,'paging.c']]],
  ['freealarm_14',['freeAlarm',['../dnt_8c.html#a393397cf31fb30d34cff1647fc9239fd',1,'freeAlarm(char *time):&#160;dnt.c'],['../dnt_8h.html#ab0c684c5eb79ddb26e42aca0c87ea6c2',1,'freeAlarm(char *alarm):&#160;dnt.c']]],
  ['freealarmhelp_15',['freealarmHelp',['../out_8h.html#a2fb2b71fe798b1a56f1d3506293e5e2e',1,'freealarmHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a2fb2b71fe798b1a56f1d3506293e5e2e',1,'freealarmHelp():&#160;help.c']]],
  ['freepcb_16',['freePCB',['../pcb_2pcb_8c.html#ad70b9648d1bd52cd26da4f857343b6b9',1,'freePCB(pcb_t *pcb):&#160;pcb.c'],['../pcb_8h.html#a810cec8bb6005272411a9beb07a1ecd4',1,'freePCB(pcb_t *freed_pcb):&#160;pcb.c']]],
  ['fs_17',['fs',['../structcontext.html#a5e778314cc8c537f0a27726bfa673c8e',1,'context']]]
];
