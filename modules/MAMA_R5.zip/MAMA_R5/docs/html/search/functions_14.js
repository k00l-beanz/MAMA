var searchData=
[
  ['write_5fgdt_5fptr_0',['write_gdt_ptr',['../tables_8c.html#ab603373c64fb0a6d51482121d0800be4',1,'tables.c']]],
  ['write_5fhist_5fto_5fbuf_1',['write_hist_to_buf',['../history_8c.html#a29bc230f76ab2f176c35703511118f62',1,'history.c']]],
  ['write_5fidt_5fptr_2',['write_idt_ptr',['../tables_8c.html#a77fec66a455d3275b67be5c3d7868555',1,'tables.c']]]
];
