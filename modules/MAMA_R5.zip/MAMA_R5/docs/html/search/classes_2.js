var searchData=
[
  ['footer_0',['footer',['../structfooter.html',1,'']]]
];
