var searchData=
[
  ['versionhelp_0',['versionHelp',['../out_8h.html#a6cd078828b9b430112c8f28038ac99f0',1,'versionHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a6cd078828b9b430112c8f28038ac99f0',1,'versionHelp():&#160;help.c']]],
  ['versionos_1',['versionOs',['../help_8c.html#a1a2c9893c7db2d78213c4fe2a77d81ba',1,'help.c']]]
];
