var searchData=
[
  ['page_5fsize_0',['PAGE_SIZE',['../paging_8h.html#a7d467c1d283fdfa1f2081ba1e0d01b6e',1,'paging.h']]],
  ['pic1_1',['PIC1',['../interrupts_8c.html#a6b115109e4a0d3c5fb6252d091e86bfe',1,'interrupts.c']]],
  ['pic2_2',['PIC2',['../interrupts_8c.html#ac90003f52c8d736193efc954ece08e58',1,'interrupts.c']]]
];
