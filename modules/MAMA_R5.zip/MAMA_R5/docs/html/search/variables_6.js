var searchData=
[
  ['f_5fqueue_0',['f_queue',['../pcb_2pcb_8c.html#a58df49d4ee18ae41d37f152507b1026f',1,'pcb.c']]],
  ['fifo_5fqueue_1',['fifo_queue',['../pcb_2pcb_8c.html#a0bb729257e8ba26995a3ff7451f54134',1,'pcb.c']]],
  ['flag_5fcount_2',['flag_count',['../structparsed__args.html#ade0889eea194c73f55eba0af1d874eca',1,'parsed_args']]],
  ['flags_3',['flags',['../structidt__entry__struct.html#a46c92bd8f07d5ff4e379a07b293c46af',1,'idt_entry_struct::flags()'],['../structgdt__entry__struct.html#afac75bdf53080168c8899c442862410a',1,'gdt_entry_struct::flags()'],['../structparsed__args.html#acddfaeda83e2d16d5b3b3f97b4afcc46',1,'parsed_args::flags()'],['../tables_8h.html#a138dda98fcd4738346af61bcca8cf4b4',1,'flags():&#160;tables.h']]],
  ['frameaddr_4',['frameaddr',['../structpage__entry.html#a68a6dc54a7ab6f7fb1a068476190bf67',1,'page_entry']]],
  ['frames_5',['frames',['../paging_8c.html#a76492529572a1a20a06076ac40d66b29',1,'paging.c']]],
  ['fs_6',['fs',['../structcontext.html#a5e778314cc8c537f0a27726bfa673c8e',1,'context']]]
];
