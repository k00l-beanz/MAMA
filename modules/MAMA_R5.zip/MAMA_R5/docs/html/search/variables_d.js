var searchData=
[
  ['named_5farg_5fcount_0',['named_arg_count',['../structparsed__args.html#a900e8a1aef5d99920479254f50c5cb9c',1,'parsed_args']]],
  ['named_5farg_5fnames_1',['named_arg_names',['../structparsed__args.html#a0638499b83b47de252322ae65ffdacbf',1,'parsed_args']]],
  ['named_5farg_5fvalues_2',['named_arg_values',['../structparsed__args.html#aa5004f4b06b69cce5df93db223ea9a9d',1,'parsed_args']]],
  ['newest_5fswitch_3',['newest_switch',['../syntax__highlight_8c.html#a2e565f2eef0f1b48072d99211313e1d2',1,'syntax_highlight.c']]],
  ['nframes_4',['nframes',['../paging_8c.html#abf36580d5618820f15388083c9313e60',1,'paging.c']]]
];
