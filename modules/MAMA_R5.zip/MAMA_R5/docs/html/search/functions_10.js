var searchData=
[
  ['read_0',['read',['../out_8c.html#ac8de4cd3207d60bb185a268c030e9282',1,'read(char *buf, int len):&#160;out.c'],['../out_8h.html#a9812cbe800ae3bc77f8ec34cb3d4575f',1,'read(char *, int):&#160;out.c']]],
  ['removepcb_1',['removePCB',['../pcb_2pcb_8c.html#a699935a9f062569a0ca42dd52171813b',1,'removePCB(pcb_t *pcb):&#160;pcb.c'],['../pcb_8h.html#a699935a9f062569a0ca42dd52171813b',1,'removePCB(pcb_t *pcb):&#160;pcb.c']]],
  ['reserved_2',['reserved',['../interrupts_8c.html#ad686e3fee8ec8346a6d8e98d970a02dd',1,'interrupts.c']]],
  ['resumeall_3',['resumeAll',['../pcb_2pcb_8c.html#ac036527aaa2149438637e19a4d877de9',1,'resumeAll(char *p):&#160;pcb.c'],['../pcb_8h.html#ac036527aaa2149438637e19a4d877de9',1,'resumeAll(char *p):&#160;pcb.c']]],
  ['resumehelp_4',['resumeHelp',['../out_8h.html#a14540d172b1aa891fe36116d0d952b0a',1,'resumeHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a14540d172b1aa891fe36116d0d952b0a',1,'resumeHelp():&#160;help.c']]],
  ['resumepcb_5',['resumePCB',['../pcb_2pcb_8c.html#ab3fc9f19ba0388566ef0d05aa96d8807',1,'resumePCB(char *args):&#160;pcb.c'],['../pcb_8h.html#a8a7e8deeb9e21a925cc9ca8d42108337',1,'resumePCB(char *name):&#160;pcb.c']]],
  ['rtc_5fisr_6',['rtc_isr',['../interrupts_8c.html#a52f2615cebbdeab188085a03c913fcf9',1,'interrupts.c']]]
];
