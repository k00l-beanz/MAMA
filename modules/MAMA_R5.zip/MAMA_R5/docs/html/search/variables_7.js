var searchData=
[
  ['gdt_5fentries_0',['gdt_entries',['../tables_8c.html#ac64ff6d00454e0b88d43b55536418288',1,'tables.c']]],
  ['gdt_5fptr_1',['gdt_ptr',['../tables_8c.html#aedb4641b02b4a269294e53be7c9b280e',1,'tables.c']]],
  ['global_5fcontext_2',['global_context',['../system_8c.html#af27117a9c1e67ba9bfef46af2a1cb8d4',1,'system.c']]],
  ['gs_3',['gs',['../structcontext.html#a54fa688ce896c5cca606323d33e1f68c',1,'context']]]
];
