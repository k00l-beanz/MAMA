var searchData=
[
  ['year_0',['year',['../structdate__time.html#ae96e2e4cc09780eaac04038e12bbe06b',1,'date_time']]]
];
