var searchData=
[
  ['icw1_0',['ICW1',['../interrupts_8c.html#ac56445256ce58f14f3c61af0cbf0cdad',1,'interrupts.c']]],
  ['icw4_1',['ICW4',['../interrupts_8c.html#a7945f331ddf94a0e0e938f825bc4d43c',1,'interrupts.c']]],
  ['idle_2',['IDLE',['../mpx__supt_8h.html#a9c21a7caee326d7803b94ae1952b27ca',1,'mpx_supt.h']]],
  ['inb_3',['inb',['../io_8h.html#ad6488a48837d179b1833e2f48dac9665',1,'io.h']]],
  ['invalid_5fbuffer_4',['INVALID_BUFFER',['../mpx__supt_8h.html#a9f45976a0d1fa6f0a85a74b6efd93835',1,'mpx_supt.h']]],
  ['invalid_5fcount_5',['INVALID_COUNT',['../mpx__supt_8h.html#a2b85babe3dc4162f5551aae5d269ba60',1,'mpx_supt.h']]],
  ['invalid_5foperation_6',['INVALID_OPERATION',['../mpx__supt_8h.html#a95d66938b0cfadb27cc1368b5e04fdb3',1,'mpx_supt.h']]],
  ['io_5fmodule_7',['IO_MODULE',['../mpx__supt_8h.html#a69d0c9d3e706f2549635aeb72dc2c9b1',1,'mpx_supt.h']]],
  ['io_5fwait_8',['io_wait',['../interrupts_8c.html#aeae4190ed25d0648577e1c742fd8a78d',1,'interrupts.c']]],
  ['iret_9',['iret',['../system_8h.html#a6eab829c77f5e1d2786863e18547b81b',1,'system.h']]]
];
