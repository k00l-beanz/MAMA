var searchData=
[
  ['color_0',['Color',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1c',1,'Color():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1c',1,'Color():&#160;colorize.h']]]
];
