var searchData=
[
  ['rc_5f1_0',['RC_1',['../procsr3_8c.html#a69bb368d802d94815d8480c1196eb868',1,'procsr3.c']]],
  ['rc_5f2_1',['RC_2',['../procsr3_8c.html#aecb625779f85a782d04475c4fb74ebc5',1,'procsr3.c']]],
  ['rc_5f3_2',['RC_3',['../procsr3_8c.html#acf180d856b90414b8bed369054fcd763',1,'procsr3.c']]],
  ['rc_5f4_3',['RC_4',['../procsr3_8c.html#ac76d64b147c7d9537915e51c7dc02bc1',1,'procsr3.c']]],
  ['rc_5f5_4',['RC_5',['../procsr3_8c.html#acba6a931785dc419ad6337bc9c1a24f8',1,'procsr3.c']]],
  ['read_5',['read',['../out_8c.html#ac8de4cd3207d60bb185a268c030e9282',1,'read(char *buf, int len):&#160;out.c'],['../out_8h.html#a9812cbe800ae3bc77f8ec34cb3d4575f',1,'read(char *, int):&#160;out.c']]],
  ['read_6',['READ',['../mpx__supt_8h.html#ada74e7db007a68e763f20c17f2985356',1,'mpx_supt.h']]],
  ['readme_2emd_7',['README.md',['../README_8md.html',1,'']]],
  ['ready_8',['READY',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa6564f2f3e15be06b670547bbcaaf0798',1,'pcb.h']]],
  ['red_9',['RED',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'RED():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'RED():&#160;colorize.h']]],
  ['removepcb_10',['removePCB',['../pcb_2pcb_8c.html#a699935a9f062569a0ca42dd52171813b',1,'removePCB(pcb_t *pcb):&#160;pcb.c'],['../pcb_8h.html#a699935a9f062569a0ca42dd52171813b',1,'removePCB(pcb_t *pcb):&#160;pcb.c']]],
  ['reserved_11',['reserved',['../structpage__entry.html#af6d963f09b01571b107e6f505050c0e5',1,'page_entry::reserved()'],['../interrupts_8c.html#ad686e3fee8ec8346a6d8e98d970a02dd',1,'reserved():&#160;interrupts.c']]],
  ['resumeall_12',['resumeAll',['../pcb_2pcb_8c.html#ac036527aaa2149438637e19a4d877de9',1,'resumeAll(char *p):&#160;pcb.c'],['../pcb_8h.html#ac036527aaa2149438637e19a4d877de9',1,'resumeAll(char *p):&#160;pcb.c']]],
  ['resumehelp_13',['resumeHelp',['../out_8h.html#a14540d172b1aa891fe36116d0d952b0a',1,'resumeHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a14540d172b1aa891fe36116d0d952b0a',1,'resumeHelp():&#160;help.c']]],
  ['resumepcb_14',['resumePCB',['../pcb_2pcb_8c.html#ab3fc9f19ba0388566ef0d05aa96d8807',1,'resumePCB(char *args):&#160;pcb.c'],['../pcb_8h.html#a8a7e8deeb9e21a925cc9ca8d42108337',1,'resumePCB(char *name):&#160;pcb.c']]],
  ['right_5farrow_15',['RIGHT_ARROW',['../serial_8c.html#a9ed2533108b634266a6261c8f37e4fc0',1,'serial.c']]],
  ['rtc_5fisr_16',['rtc_isr',['../interrupts_8c.html#a52f2615cebbdeab188085a03c913fcf9',1,'interrupts.c']]],
  ['running_17',['RUNNING',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa1061be6c3fb88d32829cba6f6b2be304',1,'pcb.h']]]
];
