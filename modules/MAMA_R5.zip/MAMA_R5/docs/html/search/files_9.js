var searchData=
[
  ['paging_2ec_0',['paging.c',['../paging_8c.html',1,'']]],
  ['paging_2eh_1',['paging.h',['../paging_8h.html',1,'']]],
  ['pcb_2ec_2',['pcb.c',['../cmds_2pcb_8c.html',1,'(Global Namespace)'],['../pcb_2pcb_8c.html',1,'(Global Namespace)']]],
  ['pcb_2eh_3',['pcb.h',['../pcb_8h.html',1,'']]],
  ['procsr3_2ec_4',['procsr3.c',['../procsr3_8c.html',1,'']]],
  ['procsr3_2eh_5',['procsr3.h',['../procsr3_8h.html',1,'']]]
];
