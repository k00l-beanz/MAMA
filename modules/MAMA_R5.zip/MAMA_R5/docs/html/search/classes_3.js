var searchData=
[
  ['gdt_5fdescriptor_5fstruct_0',['gdt_descriptor_struct',['../structgdt__descriptor__struct.html',1,'']]],
  ['gdt_5fentry_5fstruct_1',['gdt_entry_struct',['../structgdt__entry__struct.html',1,'']]]
];
