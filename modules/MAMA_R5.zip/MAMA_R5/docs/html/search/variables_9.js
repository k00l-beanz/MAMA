var searchData=
[
  ['id_0',['id',['../structindex__table.html#a6e0e8e27a6a47e8ae2078b6fa447087f',1,'index_table']]],
  ['idt_5fentries_1',['idt_entries',['../interrupts_8c.html#a3c386c59636822ce451be20cc1433a55',1,'idt_entries():&#160;tables.c'],['../tables_8c.html#a3c386c59636822ce451be20cc1433a55',1,'idt_entries():&#160;tables.c']]],
  ['idt_5fptr_2',['idt_ptr',['../tables_8c.html#a76f617adbc46449bbc39e7b46504b7c4',1,'tables.c']]],
  ['index_3',['index',['../structheap.html#a8fe6ce2a8b45088990071e9b1d35add2',1,'heap']]],
  ['index_5fid_4',['index_id',['../structheader.html#aec42bcd6139d12f84d54b5e6a149b276',1,'header']]]
];
