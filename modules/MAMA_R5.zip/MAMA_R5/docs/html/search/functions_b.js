var searchData=
[
  ['load_5fpage_5fdir_0',['load_page_dir',['../paging_8h.html#a3affceba4cd194e1c516404c14abbe7c',1,'load_page_dir(page_dir *new_page_dir):&#160;paging.c'],['../paging_8c.html#a31e6c585cbda542534f1b0fc83e40689',1,'load_page_dir(page_dir *new_dir):&#160;paging.c']]],
  ['loadr3_1',['loadr3',['../context_8c.html#ace6cc1bdb64c3a0f48c1c31ad7757f9d',1,'loadr3(char *p):&#160;context.c'],['../context_8h.html#ace6cc1bdb64c3a0f48c1c31ad7757f9d',1,'loadr3(char *p):&#160;context.c']]],
  ['loadr3help_2',['loadr3Help',['../out_8h.html#a32a6a3edb1a000f0ab8bb969c37aa5ff',1,'loadr3Help():&#160;help.c'],['../term_2cmds_2help_8c.html#a32a6a3edb1a000f0ab8bb969c37aa5ff',1,'loadr3Help():&#160;help.c']]]
];
