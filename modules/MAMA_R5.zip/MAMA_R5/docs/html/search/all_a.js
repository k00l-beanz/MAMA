var searchData=
[
  ['kdir_0',['kdir',['../heap_8c.html#a61ce943ba80d9dfab89a826cae9ddc4a',1,'kdir():&#160;paging.c'],['../paging_8c.html#a61ce943ba80d9dfab89a826cae9ddc4a',1,'kdir():&#160;paging.c']]],
  ['kfree_1',['kfree',['../heap_8h.html#aa2a6fb2aa05727dc1e7d72cbc108e63c',1,'heap.h']]],
  ['kheap_2',['kheap',['../heap_8c.html#a61825456a33b09780a5493c95adcae8a',1,'kheap():&#160;heap.c'],['../paging_8c.html#a61825456a33b09780a5493c95adcae8a',1,'kheap():&#160;heap.c']]],
  ['kheap_5fbase_3',['KHEAP_BASE',['../heap_8h.html#a15073b9742f7e29d8174509197eb4ab9',1,'heap.h']]],
  ['kheap_5fmin_4',['KHEAP_MIN',['../heap_8h.html#aee52619f74498ad224eb8e4354b89e40',1,'heap.h']]],
  ['kheap_5fsize_5',['KHEAP_SIZE',['../heap_8h.html#a0f2696767a10e6efffc64e9b459c4ea6',1,'heap.h']]],
  ['klogv_6',['klogv',['../system_8h.html#abdb09834267dd4a2a0d07d43ca4d230d',1,'klogv(const char *msg):&#160;system.c'],['../system_8c.html#abdb09834267dd4a2a0d07d43ca4d230d',1,'klogv(const char *msg):&#160;system.c']]],
  ['kmain_7',['kmain',['../kmain_8c.html#a406c20548822065e144564476378f8a1',1,'kmain.c']]],
  ['kmain_2ec_8',['kmain.c',['../kmain_8c.html',1,'']]],
  ['kmalloc_9',['kmalloc',['../heap_8h.html#a15d6a52c5c080c8c7ffc73e336d8e574',1,'kmalloc(u32int size):&#160;heap.c'],['../heap_8c.html#a15d6a52c5c080c8c7ffc73e336d8e574',1,'kmalloc(u32int size):&#160;heap.c']]],
  ['kpanic_10',['kpanic',['../system_8h.html#aff8473f901d828d76d3548130731c41d',1,'kpanic(const char *msg):&#160;system.c'],['../system_8c.html#aff8473f901d828d76d3548130731c41d',1,'kpanic(const char *msg):&#160;system.c']]]
];
