var searchData=
[
  ['gdt_5fcs_5fid_0',['GDT_CS_ID',['../system_8h.html#aeb3dcf3cb65fb9b31c3d6b9ddb576071',1,'system.h']]],
  ['gdt_5fds_5fid_1',['GDT_DS_ID',['../system_8h.html#a90303dd4b4639f2e4106ced8d18fb4a1',1,'system.h']]]
];
