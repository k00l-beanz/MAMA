var searchData=
[
  ['day_5fm_0',['day_m',['../structdate__time.html#a72ee4f3a6a9970e58861c868bc676ba2',1,'date_time']]],
  ['day_5fw_1',['day_w',['../structdate__time.html#aa021771ff83fe860afaaf158932fcb15',1,'date_time']]],
  ['day_5fy_2',['day_y',['../structdate__time.html#ad89b6054376708a35bc1c0a186c808ca',1,'date_time']]],
  ['device_5fid_3',['device_id',['../structparam.html#a44a7285b02749114186a9f9971941bcb',1,'param']]],
  ['dirty_4',['dirty',['../structpage__entry.html#ab3b5e22c6146f227a26bdec64e63f4b0',1,'page_entry']]],
  ['ds_5',['ds',['../structcontext.html#ae636622afec7fe9c8b18504168023d1e',1,'context']]]
];
