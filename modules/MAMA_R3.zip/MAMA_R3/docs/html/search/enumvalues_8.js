var searchData=
[
  ['ready_0',['READY',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa6564f2f3e15be06b670547bbcaaf0798',1,'pcb.h']]],
  ['red_1',['RED',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'RED():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'RED():&#160;colorize.h']]],
  ['running_2',['RUNNING',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa1061be6c3fb88d32829cba6f6b2be304',1,'pcb.h']]]
];
