var searchData=
[
  ['green_0',['GREEN',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caa60bd322f93178d68184e30e162571ca',1,'GREEN():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caa60bd322f93178d68184e30e162571ca',1,'GREEN():&#160;colorize.h']]]
];
