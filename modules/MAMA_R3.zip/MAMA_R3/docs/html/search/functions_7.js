var searchData=
[
  ['gdt_5finit_5fentry_0',['gdt_init_entry',['../tables_8c.html#a0b5aee548c88c40ecb07741be1be2e27',1,'gdt_init_entry(int idx, u32int base, u32int limit, u8int access, u8int flags):&#160;tables.c'],['../tables_8h.html#a0b5aee548c88c40ecb07741be1be2e27',1,'gdt_init_entry(int idx, u32int base, u32int limit, u8int access, u8int flags):&#160;tables.c']]],
  ['general_5fprotection_1',['general_protection',['../interrupts_8c.html#a10777dd6c3a040471676741bbb8dda46',1,'interrupts.c']]],
  ['get_5fbit_2',['get_bit',['../paging_8h.html#a317b4797bc81f65bd01cfa190800ecdd',1,'get_bit(u32int addr):&#160;paging.c'],['../paging_8c.html#a317b4797bc81f65bd01cfa190800ecdd',1,'get_bit(u32int addr):&#160;paging.c']]],
  ['get_5fpage_3',['get_page',['../paging_8h.html#a47e4570159b06b34c82bd7bd8a9a5afb',1,'get_page(u32int addr, page_dir *dir, int make_table):&#160;paging.c'],['../paging_8c.html#a47e4570159b06b34c82bd7bd8a9a5afb',1,'get_page(u32int addr, page_dir *dir, int make_table):&#160;paging.c']]],
  ['get_5fstate_4',['get_state',['../syntax_8c.html#a1fdb9b4b03628198cd78d508b907a25f',1,'get_state(char c, enum SyntaxState cur_state):&#160;syntax.c'],['../syntax_8h.html#ac7d49ef60cb2864658aa70a30a456d09',1,'get_state(char, enum SyntaxState):&#160;syntax.c']]],
  ['get_5fstate_5fat_5',['get_state_at',['../syntax__highlight_8c.html#a1cb7c40b079a85723604d8b3256a9f85',1,'syntax_highlight.c']]],
  ['get_5ftoken_6',['get_token',['../args_8c.html#a6665bcb29bd854bd8343e00686d3722b',1,'args.c']]],
  ['getdate_7',['getdate',['../dnt_8c.html#a1b6c333c9d6fb565020fcb5de3d2b90d',1,'getdate(char *p):&#160;dnt.c'],['../dnt_8h.html#a1b6c333c9d6fb565020fcb5de3d2b90d',1,'getdate(char *p):&#160;dnt.c']]],
  ['getdatehelp_8',['getdateHelp',['../help_8c.html#af5a3edef6ac29bfbdb319c3f40a2eb21',1,'getdateHelp():&#160;help.c'],['../out_8h.html#af5a3edef6ac29bfbdb319c3f40a2eb21',1,'getdateHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#af5a3edef6ac29bfbdb319c3f40a2eb21',1,'getdateHelp():&#160;help.c']]],
  ['gettime_9',['gettime',['../dnt_8c.html#a8adbb1f302ef7d45187a37bec630abcd',1,'gettime(char *p):&#160;dnt.c'],['../dnt_8h.html#a8adbb1f302ef7d45187a37bec630abcd',1,'gettime(char *p):&#160;dnt.c']]],
  ['gettimehelp_10',['gettimeHelp',['../help_8c.html#a31b0d4a8a8716551c8dc1d023bca5e03',1,'gettimeHelp():&#160;help.c'],['../out_8h.html#a31b0d4a8a8716551c8dc1d023bca5e03',1,'gettimeHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a31b0d4a8a8716551c8dc1d023bca5e03',1,'gettimeHelp():&#160;help.c']]]
];
