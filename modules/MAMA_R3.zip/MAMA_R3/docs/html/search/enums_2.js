var searchData=
[
  ['syntaxstate_0',['SyntaxState',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83',1,'syntax.h']]]
];
