var searchData=
[
  ['default_0',['DEFAULT',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83a88ec7d5086d2469ba843c7fcceade8a6',1,'syntax.h']]],
  ['double_5fquote_5fstring_1',['DOUBLE_QUOTE_STRING',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83ae7db3de1e657bbe2e8259e7ca2d9793c',1,'syntax.h']]],
  ['double_5fquote_5fstring_5fend_5fquote_2',['DOUBLE_QUOTE_STRING_END_QUOTE',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83a242f8b0468adf6dc6dd3519ddd37ed04',1,'syntax.h']]]
];
