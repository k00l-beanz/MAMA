var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwyz",
  1: "cdfghip",
  2: "acdehikmoprstuvw",
  3: "_abcdefghiklmnoprsuvw",
  4: "_abcdefghiklmnopqrstuwyz",
  5: "cpsu",
  6: "cps",
  7: "bcdefgmprswy",
  8: "acdefghiklmnoprstuvw",
  9: "mw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

