var searchData=
[
  ['date_5ftime_0',['date_time',['../structdate__time.html',1,'']]]
];
