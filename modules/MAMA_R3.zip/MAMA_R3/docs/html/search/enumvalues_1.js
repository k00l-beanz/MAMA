var searchData=
[
  ['cmd_5fname_0',['CMD_NAME',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83aeb55efc71570e1830a0070d06af683b4',1,'syntax.h']]],
  ['cmd_5fname_5for_5fleading_5fwhitespace_1',['CMD_NAME_OR_LEADING_WHITESPACE',['../syntax_8h.html#af33280939207bc6f00c4b91581c64e83a34d0593ff40f9bfd598cf63104c18a96',1,'syntax.h']]],
  ['cyan_2',['CYAN',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caafe71cad474c15ce63b300c470eef8cc',1,'CYAN():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caafe71cad474c15ce63b300c470eef8cc',1,'CYAN():&#160;colorize.h']]]
];
