var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../tables_8h.html#a8c598adbe324e6cc36ed5183576a5f27',1,'tables.h']]],
  ['_5f_5fend_1',['__end',['../heap_8c.html#a51f2442fadb8ffd3019f4aeb1b04c4d6',1,'heap.c']]],
  ['_5fend_2',['_end',['../heap_8c.html#a850b19392dca6170001ce200467ab610',1,'heap.c']]],
  ['_5fkmalloc_3',['_kmalloc',['../heap_8h.html#a9bfb8053c2382598ef5b2175f475d49a',1,'_kmalloc(u32int size, int align, u32int *phys_addr):&#160;heap.c'],['../heap_8c.html#a014b54e36b61f133f53dd509c461f35e',1,'_kmalloc(u32int size, int page_align, u32int *phys_addr):&#160;heap.c']]]
];
