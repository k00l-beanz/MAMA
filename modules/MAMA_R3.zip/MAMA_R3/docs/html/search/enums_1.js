var searchData=
[
  ['p_5fstate_5ft_0',['p_state_t',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31f',1,'pcb.h']]],
  ['pcb_5fqueue_5forder_5ft_1',['pcb_queue_order_t',['../pcb_8h.html#ab4997200d0dfc40cf82ea4983950ae64',1,'pcb.h']]]
];
