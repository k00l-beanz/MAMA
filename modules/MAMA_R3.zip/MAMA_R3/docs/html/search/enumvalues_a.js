var searchData=
[
  ['white_0',['WHITE',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1ca283fc479650da98250635b9c3c0e7e50',1,'WHITE():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1ca283fc479650da98250635b9c3c0e7e50',1,'WHITE():&#160;colorize.h']]]
];
