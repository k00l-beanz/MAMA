var searchData=
[
  ['kfree_0',['kfree',['../heap_8h.html#aa2a6fb2aa05727dc1e7d72cbc108e63c',1,'heap.h']]],
  ['klogv_1',['klogv',['../system_8h.html#abdb09834267dd4a2a0d07d43ca4d230d',1,'klogv(const char *msg):&#160;system.c'],['../system_8c.html#abdb09834267dd4a2a0d07d43ca4d230d',1,'klogv(const char *msg):&#160;system.c']]],
  ['kmain_2',['kmain',['../kmain_8c.html#a406c20548822065e144564476378f8a1',1,'kmain.c']]],
  ['kmalloc_3',['kmalloc',['../heap_8h.html#a15d6a52c5c080c8c7ffc73e336d8e574',1,'kmalloc(u32int size):&#160;heap.c'],['../heap_8c.html#a15d6a52c5c080c8c7ffc73e336d8e574',1,'kmalloc(u32int size):&#160;heap.c']]],
  ['kpanic_4',['kpanic',['../system_8h.html#aff8473f901d828d76d3548130731c41d',1,'kpanic(const char *msg):&#160;system.c'],['../system_8c.html#aff8473f901d828d76d3548130731c41d',1,'kpanic(const char *msg):&#160;system.c']]]
];
