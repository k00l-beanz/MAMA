var searchData=
[
  ['mama_0',['MAMA',['../md__home_maximillian_Desktop_MAMA_README.html',1,'']]]
];
