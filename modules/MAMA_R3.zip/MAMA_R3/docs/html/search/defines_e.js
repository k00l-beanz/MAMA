var searchData=
[
  ['read_0',['READ',['../mpx__supt_8h.html#ada74e7db007a68e763f20c17f2985356',1,'mpx_supt.h']]],
  ['right_5farrow_1',['RIGHT_ARROW',['../serial_8c.html#a9ed2533108b634266a6261c8f37e4fc0',1,'serial.c']]]
];
