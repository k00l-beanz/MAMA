var searchData=
[
  ['unblockhelp_0',['unblockHelp',['../out_8h.html#a3b8298ed0c79ad11464326a9c22b8d9a',1,'unblockHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a3b8298ed0c79ad11464326a9c22b8d9a',1,'unblockHelp():&#160;help.c']]],
  ['unblockpcb_1',['unblockPCB',['../pcb_2pcb_8c.html#a9be98649f5ef1f42228d3930c256f25c',1,'unblockPCB(char *name):&#160;pcb.c'],['../pcb_8h.html#a9be98649f5ef1f42228d3930c256f25c',1,'unblockPCB(char *name):&#160;pcb.c']]]
];
