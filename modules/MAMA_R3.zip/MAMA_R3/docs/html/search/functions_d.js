var searchData=
[
  ['named_5farg_0',['named_arg',['../args_8c.html#aab5cb37daa27a21e9a724fc3c7116b3c',1,'args.c']]],
  ['new_5fframe_1',['new_frame',['../paging_8h.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c'],['../paging_8c.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c']]],
  ['next_5funnamed_5farg_2',['next_unnamed_arg',['../args_8c.html#ab20b340816a71f3368f6dd610678f8d8',1,'args.c']]],
  ['nmi_3',['nmi',['../interrupts_8c.html#aa42d18df06cf68f8c05fded5344c4c7e',1,'interrupts.c']]]
];
