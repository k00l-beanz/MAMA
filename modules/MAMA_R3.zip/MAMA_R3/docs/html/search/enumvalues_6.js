var searchData=
[
  ['magenta_0',['MAGENTA',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1ca56926c820ad72d0977e7ee44d9916e62',1,'MAGENTA():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1ca56926c820ad72d0977e7ee44d9916e62',1,'MAGENTA():&#160;colorize.h']]]
];
