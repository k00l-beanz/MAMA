var searchData=
[
  ['start_5fseq_0',['START_SEQ',['../colorize_8c.html#a0e263175c08c00143ac9a19616a6169e',1,'colorize.c']]],
  ['sti_1',['sti',['../system_8h.html#ac5d15f274bc9b1e96230f3d3c60fd1f8',1,'system.h']]],
  ['syntax_5fcolor_5fcmd_5fname_2',['SYNTAX_COLOR_CMD_NAME',['../syntax__highlight_8h.html#ab0fd78b0e2ff8d9ab306f5c9fed26f3c',1,'syntax_highlight.h']]],
  ['syntax_5fcolor_5fdefault_3',['SYNTAX_COLOR_DEFAULT',['../syntax__highlight_8h.html#a81ea42ad7ff6d211c86f7435ced03d6a',1,'syntax_highlight.h']]],
  ['syntax_5fcolor_5fdouble_5fquote_5fstring_4',['SYNTAX_COLOR_DOUBLE_QUOTE_STRING',['../syntax__highlight_8h.html#ae67c604283a21ea5dfdfff6e23ed8661',1,'syntax_highlight.h']]],
  ['syntax_5fcolor_5fparam_5fname_5',['SYNTAX_COLOR_PARAM_NAME',['../syntax__highlight_8h.html#afccbe35bf8ef95e96c7f1ebbddb9f451',1,'syntax_highlight.h']]],
  ['syntax_5fcolor_5fparam_5fvalue_6',['SYNTAX_COLOR_PARAM_VALUE',['../syntax__highlight_8h.html#a7e38d369114b0fb029b1b6a86ee76e32',1,'syntax_highlight.h']]],
  ['syntax_5fcolor_5fsingle_5fquote_5fstring_7',['SYNTAX_COLOR_SINGLE_QUOTE_STRING',['../syntax__highlight_8h.html#ac8954b47e6ceb0c6daba551eb4d3df91',1,'syntax_highlight.h']]]
];
