var searchData=
[
  ['make_5fheap_0',['make_heap',['../heap_8h.html#abf10fb79c17a354e68c11652bc5f9d0c',1,'make_heap(u32int base, u32int max, u32int min):&#160;heap.c'],['../heap_8c.html#abf10fb79c17a354e68c11652bc5f9d0c',1,'make_heap(u32int base, u32int max, u32int min):&#160;heap.c']]],
  ['mama_1',['mama',['../mama_8c.html#aed0dd46d9235214865df92ed6637a4f8',1,'mama():&#160;mama.c'],['../mama_8h.html#aed0dd46d9235214865df92ed6637a4f8',1,'mama():&#160;mama.c']]],
  ['memset_2',['memset',['../string_8h.html#a313175102214d45434bf045db18dddf0',1,'memset(void *s, int c, size_t n):&#160;string.c'],['../string_8c.html#a313175102214d45434bf045db18dddf0',1,'memset(void *s, int c, size_t n):&#160;string.c']]],
  ['mpx_5finit_3',['mpx_init',['../mpx__supt_8c.html#a53332c6a3107a4feed6e2e79690a6ffa',1,'mpx_init(int cur_mod):&#160;mpx_supt.c'],['../mpx__supt_8h.html#a53332c6a3107a4feed6e2e79690a6ffa',1,'mpx_init(int cur_mod):&#160;mpx_supt.c']]]
];
