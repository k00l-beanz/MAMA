var searchData=
[
  ['read_0',['READ',['../mpx__supt_8h.html#ada74e7db007a68e763f20c17f2985356',1,'mpx_supt.h']]],
  ['read_1',['read',['../out_8c.html#ac8de4cd3207d60bb185a268c030e9282',1,'read(char *buf, int len):&#160;out.c'],['../out_8h.html#a9812cbe800ae3bc77f8ec34cb3d4575f',1,'read(char *, int):&#160;out.c']]],
  ['readme_2emd_2',['README.md',['../README_8md.html',1,'']]],
  ['ready_3',['READY',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa6564f2f3e15be06b670547bbcaaf0798',1,'pcb.h']]],
  ['red_4',['RED',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'RED():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'RED():&#160;colorize.h']]],
  ['removepcb_5',['removePCB',['../pcb_2pcb_8c.html#a699935a9f062569a0ca42dd52171813b',1,'removePCB(pcb_t *pcb):&#160;pcb.c'],['../pcb_8h.html#a699935a9f062569a0ca42dd52171813b',1,'removePCB(pcb_t *pcb):&#160;pcb.c']]],
  ['reserved_6',['reserved',['../structpage__entry.html#af6d963f09b01571b107e6f505050c0e5',1,'page_entry::reserved()'],['../interrupts_8c.html#ad686e3fee8ec8346a6d8e98d970a02dd',1,'reserved():&#160;interrupts.c']]],
  ['resumehelp_7',['resumeHelp',['../out_8h.html#a14540d172b1aa891fe36116d0d952b0a',1,'resumeHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a14540d172b1aa891fe36116d0d952b0a',1,'resumeHelp():&#160;help.c']]],
  ['resumepcb_8',['resumePCB',['../pcb_2pcb_8c.html#ab3fc9f19ba0388566ef0d05aa96d8807',1,'resumePCB(char *args):&#160;pcb.c'],['../pcb_8h.html#a8a7e8deeb9e21a925cc9ca8d42108337',1,'resumePCB(char *name):&#160;pcb.c']]],
  ['right_5farrow_9',['RIGHT_ARROW',['../serial_8c.html#a9ed2533108b634266a6261c8f37e4fc0',1,'serial.c']]],
  ['rtc_5fisr_10',['rtc_isr',['../interrupts_8c.html#a52f2615cebbdeab188085a03c913fcf9',1,'interrupts.c']]],
  ['running_11',['RUNNING',['../pcb_8h.html#a4f8f003be709b151ad2f3ccaaacac31fa1061be6c3fb88d32829cba6f6b2be304',1,'pcb.h']]]
];
