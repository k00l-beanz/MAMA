var searchData=
[
  ['kheap_5fbase_0',['KHEAP_BASE',['../heap_8h.html#a15073b9742f7e29d8174509197eb4ab9',1,'heap.h']]],
  ['kheap_5fmin_1',['KHEAP_MIN',['../heap_8h.html#aee52619f74498ad224eb8e4354b89e40',1,'heap.h']]],
  ['kheap_5fsize_2',['KHEAP_SIZE',['../heap_8h.html#a0f2696767a10e6efffc64e9b459c4ea6',1,'heap.h']]]
];
