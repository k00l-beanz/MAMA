var searchData=
[
  ['head_0',['head',['../structfooter.html#acae33dac61c9505ff5b850f88d32dd0b',1,'footer']]],
  ['hour_1',['hour',['../structdate__time.html#a4331b46df7b89763a85ea97a246c4ee2',1,'date_time']]]
];
