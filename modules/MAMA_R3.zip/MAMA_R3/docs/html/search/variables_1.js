var searchData=
[
  ['access_0',['access',['../structgdt__entry__struct.html#a7457cb21f29e919a8ea62fc0110ac238',1,'gdt_entry_struct::access()'],['../tables_8h.html#a360a726ac0b61d9e4e1be3ad34f80244',1,'access():&#160;tables.h']]],
  ['accessed_1',['accessed',['../structpage__entry.html#a8b4097e0cee08d028182b11bd1f73f92',1,'page_entry']]]
];
