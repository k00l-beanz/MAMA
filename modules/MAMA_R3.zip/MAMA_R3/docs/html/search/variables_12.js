var searchData=
[
  ['sec_0',['sec',['../structdate__time.html#ac43a109ccc7f3c46840afa8a30dc51f1',1,'date_time']]],
  ['serial_5fport_5fin_1',['serial_port_in',['../serial_8c.html#a1a756238531fc5bf1096f89dc18e835e',1,'serial.c']]],
  ['serial_5fport_5fout_2',['serial_port_out',['../serial_8c.html#adbb2c18b0aaab5c1927a6f674768a710',1,'serial.c']]],
  ['size_3',['size',['../structheader.html#af8cc659f702446226bc2ebabba437d5d',1,'header::size()'],['../structindex__entry.html#a2b0247aae5c7f9884f8eef1ee121adb0',1,'index_entry::size()']]],
  ['sselect_4',['sselect',['../structidt__entry__struct.html#a85254c7df6a612f4a4b3bb470ff3370c',1,'idt_entry_struct::sselect()'],['../tables_8h.html#ab3f34507900160b4a9b309b4ed039e07',1,'sselect():&#160;tables.h']]],
  ['stack_5fsize_5',['stack_size',['../args_8c.html#ac80d2e8d634bda960452fbb6e9f5f7d9',1,'args.c']]],
  ['states_6',['states',['../syntax__highlight_8c.html#ab89bad94c0c01115a8fe6f4a7dbc0d6f',1,'syntax_highlight.c']]],
  ['student_5ffree_7',['student_free',['../mpx__supt_8c.html#a19c47c02b0338bc13716d98305bb8a34',1,'mpx_supt.c']]],
  ['student_5fmalloc_8',['student_malloc',['../mpx__supt_8c.html#a421e2b48efb5facc71d16979252710e2',1,'mpx_supt.c']]],
  ['switch_5findexes_9',['switch_indexes',['../syntax__highlight_8c.html#a30d4d1c39337175e8ca12046c7563a2f',1,'syntax_highlight.c']]]
];
