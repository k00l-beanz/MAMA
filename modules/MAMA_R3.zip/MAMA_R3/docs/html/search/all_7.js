var searchData=
[
  ['gdt_5fcs_5fid_0',['GDT_CS_ID',['../system_8h.html#aeb3dcf3cb65fb9b31c3d6b9ddb576071',1,'system.h']]],
  ['gdt_5fdescriptor_5fstruct_1',['gdt_descriptor_struct',['../structgdt__descriptor__struct.html',1,'']]],
  ['gdt_5fds_5fid_2',['GDT_DS_ID',['../system_8h.html#a90303dd4b4639f2e4106ced8d18fb4a1',1,'system.h']]],
  ['gdt_5fentries_3',['gdt_entries',['../tables_8c.html#ac64ff6d00454e0b88d43b55536418288',1,'tables.c']]],
  ['gdt_5fentry_5fstruct_4',['gdt_entry_struct',['../structgdt__entry__struct.html',1,'']]],
  ['gdt_5finit_5fentry_5',['gdt_init_entry',['../tables_8h.html#a0b5aee548c88c40ecb07741be1be2e27',1,'gdt_init_entry(int idx, u32int base, u32int limit, u8int access, u8int flags):&#160;tables.c'],['../tables_8c.html#a0b5aee548c88c40ecb07741be1be2e27',1,'gdt_init_entry(int idx, u32int base, u32int limit, u8int access, u8int flags):&#160;tables.c']]],
  ['gdt_5fptr_6',['gdt_ptr',['../tables_8c.html#aedb4641b02b4a269294e53be7c9b280e',1,'tables.c']]],
  ['general_5fprotection_7',['general_protection',['../interrupts_8c.html#a10777dd6c3a040471676741bbb8dda46',1,'interrupts.c']]],
  ['get_5fbit_8',['get_bit',['../paging_8h.html#a317b4797bc81f65bd01cfa190800ecdd',1,'get_bit(u32int addr):&#160;paging.c'],['../paging_8c.html#a317b4797bc81f65bd01cfa190800ecdd',1,'get_bit(u32int addr):&#160;paging.c']]],
  ['get_5fpage_9',['get_page',['../paging_8h.html#a47e4570159b06b34c82bd7bd8a9a5afb',1,'get_page(u32int addr, page_dir *dir, int make_table):&#160;paging.c'],['../paging_8c.html#a47e4570159b06b34c82bd7bd8a9a5afb',1,'get_page(u32int addr, page_dir *dir, int make_table):&#160;paging.c']]],
  ['get_5fstate_10',['get_state',['../syntax_8h.html#ac7d49ef60cb2864658aa70a30a456d09',1,'get_state(char, enum SyntaxState):&#160;syntax.c'],['../syntax_8c.html#a1fdb9b4b03628198cd78d508b907a25f',1,'get_state(char c, enum SyntaxState cur_state):&#160;syntax.c']]],
  ['get_5fstate_5fat_11',['get_state_at',['../syntax__highlight_8c.html#a1cb7c40b079a85723604d8b3256a9f85',1,'syntax_highlight.c']]],
  ['get_5ftoken_12',['get_token',['../args_8c.html#a6665bcb29bd854bd8343e00686d3722b',1,'args.c']]],
  ['getdate_13',['getdate',['../dnt_8c.html#a1b6c333c9d6fb565020fcb5de3d2b90d',1,'getdate(char *p):&#160;dnt.c'],['../dnt_8h.html#a1b6c333c9d6fb565020fcb5de3d2b90d',1,'getdate(char *p):&#160;dnt.c']]],
  ['getdatehelp_14',['getdateHelp',['../help_8c.html#af5a3edef6ac29bfbdb319c3f40a2eb21',1,'getdateHelp():&#160;help.c'],['../out_8h.html#af5a3edef6ac29bfbdb319c3f40a2eb21',1,'getdateHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#af5a3edef6ac29bfbdb319c3f40a2eb21',1,'getdateHelp():&#160;help.c']]],
  ['gettime_15',['gettime',['../dnt_8c.html#a8adbb1f302ef7d45187a37bec630abcd',1,'gettime(char *p):&#160;dnt.c'],['../dnt_8h.html#a8adbb1f302ef7d45187a37bec630abcd',1,'gettime(char *p):&#160;dnt.c']]],
  ['gettimehelp_16',['gettimeHelp',['../help_8c.html#a31b0d4a8a8716551c8dc1d023bca5e03',1,'gettimeHelp():&#160;help.c'],['../out_8h.html#a31b0d4a8a8716551c8dc1d023bca5e03',1,'gettimeHelp():&#160;help.c'],['../term_2cmds_2help_8c.html#a31b0d4a8a8716551c8dc1d023bca5e03',1,'gettimeHelp():&#160;help.c']]],
  ['green_17',['GREEN',['../colorize_8c.html#ab87bacfdad76e61b9412d7124be44c1caa60bd322f93178d68184e30e162571ca',1,'GREEN():&#160;colorize.c'],['../colorize_8h.html#ab87bacfdad76e61b9412d7124be44c1caa60bd322f93178d68184e30e162571ca',1,'GREEN():&#160;colorize.h']]]
];
